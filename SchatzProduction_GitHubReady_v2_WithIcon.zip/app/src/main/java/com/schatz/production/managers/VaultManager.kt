package com.schatz.production.managers

import android.content.Context
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class VaultManager(private val context: Context) {
    data class VaultFile(val id: String, val name: String, val size: Long, val path: String, val type: VaultType, val ownerId: Long, val isShared: Boolean, val timestamp: Long)
    enum class VaultType { IMAGE, VIDEO, DOCUMENT, OTHER }

    private val _personalFiles = MutableStateFlow<List<VaultFile>>(emptyList())
    val personalFiles: StateFlow<List<VaultFile>> = _personalFiles
    private val _sharedFiles = MutableStateFlow<List<VaultFile>>(emptyList())
    val sharedFiles: StateFlow<List<VaultFile>> = _sharedFiles

    private fun getPersonalDir(userId: Long): File { return File(context.filesDir, "vault_personal_$userId").apply { mkdirs() } }
    private fun getSharedDir(): File { return File(context.filesDir, "vault_shared").apply { mkdirs() } }

    fun loadVaults(myId: Long) {
        val personalDir = getPersonalDir(myId)
        val personal = personalDir.listFiles()?.map { file ->
            VaultFile(file.name, file.name, file.length(), file.absolutePath, getType(file.name), myId, false, file.lastModified())
        } ?: emptyList()
        _personalFiles.value = personal
        val sharedDir = getSharedDir()
        val shared = sharedDir.listFiles()?.map { file ->
            VaultFile(file.name, file.name, file.length(), file.absolutePath, getType(file.name), 0, true, file.lastModified())
        } ?: emptyList()
        _sharedFiles.value = shared
    }

    fun uploadToPersonal(file: File, myId: Long) {
        val dest = File(getPersonalDir(myId), file.name)
        file.copyTo(dest, overwrite = true)
        loadVaults(myId)
    }

    fun uploadToShared(file: File) {
        val dest = File(getSharedDir(), file.name)
        file.copyTo(dest, overwrite = true)
        _sharedFiles.value = _sharedFiles.value + VaultFile(file.name, file.name, file.length(), dest.absolutePath, getType(file.name), 0, true, System.currentTimeMillis())
    }

    fun deletePersonal(fileId: String, myId: Long) {
        val file = File(getPersonalDir(myId), fileId)
        if(file.exists()) file.delete()
        loadVaults(myId)
    }

    fun deleteShared(fileId: String) {
        val file = File(getSharedDir(), fileId)
        if(file.exists()) file.delete()
        _sharedFiles.value = _sharedFiles.value.filter { it.id != fileId }
    }

    private fun getType(name: String): VaultType {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when(ext) {
            "jpg","jpeg","png","webp" -> VaultType.IMAGE
            "mp4","mov","avi","mkv" -> VaultType.VIDEO
            "pdf","doc","docx","xls","xlsx","txt" -> VaultType.DOCUMENT
            else -> VaultType.OTHER
        }
    }

    fun getStorageUsage(myId: Long): Long {
        val personalSize = getPersonalDir(myId).listFiles()?.sumOf { it.length() } ?: 0
        val sharedSize = getSharedDir().listFiles()?.sumOf { it.length() } ?: 0
        return personalSize + sharedSize
    }
}
