package com.schatz.production.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.schatz.production.managers.*

@Composable
fun SchatzApp(tdLib: TdLibUpdateManager, connectionManager: ConnectionManager, vaultManager: VaultManager, callManager: CallManager, securityManager: SecurityManager, voiceManager: VoiceMessageManager, callHistoryManager: CallHistoryManager, notificationManager: SchatzNotificationManager, fileManager: FileManager, chatManager: ChatManager, sharedVaultSyncManager: SharedVaultSyncManager, isDark: Boolean, onToggleDark:()->Unit) {
    var selected by remember { mutableStateOf(0) }
    val connectionState by connectionManager.state.collectAsState()
    val lastSeen by connectionManager.lastSeen.collectAsState()
    val callState by callManager.callState.collectAsState()
    val isInCall = callState != CallState.IDLE && callState != CallState.ENDED

    LaunchedEffect(callState) {
        if(callState == CallState.INCOMING || callState == CallState.RINGING) {
            notificationManager.showIncomingCallNotification("Her", callManager.isVideoEnabled.value, 0)
        } else if(callState == CallState.MISSED) {
            notificationManager.showMissedCallNotification("Her", callManager.isVideoEnabled.value)
            callHistoryManager.addFromCallState(callState, connectionManager.partnerId, "Her", if(callManager.isVideoEnabled.value) CallMedia.VIDEO else CallMedia.AUDIO, callManager.duration.value, false)
        } else if(callState == CallState.ENDED) {
            notificationManager.cancelIncomingCallNotification()
            callHistoryManager.addFromCallState(callState, connectionManager.partnerId, "Her", if(callManager.isVideoEnabled.value) CallMedia.VIDEO else CallMedia.AUDIO, callManager.duration.value, true)
        }
    }

    Scaffold(
        topBar = {
            if(!isInCall) {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment=Alignment.CenterHorizontally) {
                            Text("Schatz", style=MaterialTheme.typography.titleMedium)
                            Text(text=when(connectionState) {
                                ConnectionState.CONNECTED -> lastSeen
                                ConnectionState.CONNECTING -> "Connecting..."
                                ConnectionState.RECONNECTING -> "Reconnecting..."
                                ConnectionState.OFFLINE -> "Offline"
                                ConnectionState.AUTH_REQUIRED -> "Login required"
                                ConnectionState.ERROR -> "Connection error"
                            }, style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=0.6f))
                        }
                    },
                    actions = {
                        val partner = connectionManager.partner.collectAsState().value
                        IconButton(onClick={ partner?.let { callManager.startCall(it.id, false) } }) { Text("📞") }
                        IconButton(onClick={ partner?.let { callManager.startCall(it.id, true) } }) { Text("🎥") }
                    }
                )
            }
        },
        bottomBar = {
            if(!isInCall) {
                NavigationBar(tonalElevation=0.dp) {
                    NavigationBarItem(selected=selected==0, onClick={selected=0}, icon={Text("💬")}, label={Text("Chat")})
                    NavigationBarItem(selected=selected==1, onClick={selected=1}, icon={Text("📞")}, label={Text("Calls")})
                    NavigationBarItem(selected=selected==2, onClick={selected=2}, icon={Text("🗂️")}, label={Text("Vault")})
                    NavigationBarItem(selected=selected==3, onClick={selected=3}, icon={Text("⚙️")}, label={Text("Settings")})
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when {
                isInCall -> CallScreen(callManager=callManager)
                selected==0 -> ChatScreen(tdLib=tdLib, connectionManager=connectionManager, voiceManager=voiceManager)
                selected==1 -> CallHistoryScreen(callHistoryManager=callHistoryManager, callManager=callManager, partnerId=connectionManager.partnerId)
                selected==2 -> VaultScreenWithSync(syncManager=sharedVaultSyncManager, vaultManager=vaultManager, myId=connectionManager.myId)
                selected==3 -> SettingsScreen(securityManager=securityManager, isDark=isDark, onToggleDark=onToggleDark)
            }
        }
    }
}
