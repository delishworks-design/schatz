package com.schatz.production.managers

import android.content.Context
import org.drinkless.tdlib.TdApi
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class SyncState { SYNCED, SYNCING, FAILED, OFFLINE }

data class SharedVaultFile(
    val id: String,
    val name: String,
    val size: Long,
    val path: String,
    val type: VaultManager.VaultType,
    val ownerId: Long,
    val timestamp: Long,
    val syncState: SyncState,
    val messageId: Long = 0 // TDLib message id for sync
)

class SharedVaultSyncManager(private val context: Context, private val tdLib: TdLibUpdateManager, private val vaultManager: VaultManager) {
    private val _files = MutableStateFlow<List<SharedVaultFile>>(emptyList())
    val files: StateFlow<List<SharedVaultFile>> = _files

    private val _syncState = MutableStateFlow(SyncState.SYNCED)
    val syncState: StateFlow<SyncState> = _syncState

    private var currentChatId: Long = 0
    private var myId: Long = 0

    fun init(myId: Long, chatId: Long) {
        this.myId = myId
        this.currentChatId = chatId

        // Load local shared files
        loadLocalFiles()

        // Listen for shared vault files via TDLib messages
        // When partner uploads to shared vault, they send as document with caption [SHARED_VAULT]
        tdLib.onNewMessage = { tdMessage ->
            if(tdMessage.chatId == currentChatId) {
                handlePotentialSharedVaultMessage(tdMessage)
            }
        }
    }

    private fun loadLocalFiles() {
        val sharedDir = File(context.filesDir, "vault_shared").apply { mkdirs() }
        val localFiles = sharedDir.listFiles()?.map { file ->
            SharedVaultFile(
                id = file.name,
                name = file.name,
                size = file.length(),
                path = file.absolutePath,
                type = getType(file.name),
                ownerId = 0,
                timestamp = file.lastModified(),
                syncState = SyncState.SYNCED
            )
        } ?: emptyList()
        _files.value = localFiles
    }

    private fun handlePotentialSharedVaultMessage(message: TdApi.Message) {
        val content = message.content
        val caption = when(content) {
            is TdApi.MessageDocument -> content.caption.text
            is TdApi.MessagePhoto -> content.caption.text
            is TdApi.MessageVideo -> content.caption.text
            else -> ""
        }

        // Check if this is a shared vault file (caption contains [SHARED_VAULT])
        if(caption.contains("[SHARED_VAULT]")) {
            val file = when(content) {
                is TdApi.MessageDocument -> content.document.document
                is TdApi.MessagePhoto -> content.photo.sizes.lastOrNull()?.photo
                is TdApi.MessageVideo -> content.video.video
                else -> null
            }

            file?.let { tdFile ->
                // Download file to shared vault
                _syncState.value = SyncState.SYNCING
                tdLib.downloadFile(tdFile.id, 32) { downloadedFile ->
                    if(downloadedFile.local?.isDownloadingCompleted == true) {
                        val dest = File(context.filesDir, "vault_shared/${downloadedFile.local.path.substringAfterLast('/')}")
                        File(downloadedFile.local.path).copyTo(dest, overwrite = true)

                        val sharedFile = SharedVaultFile(
                            id = dest.name,
                            name = dest.name,
                            size = dest.length(),
                            path = dest.absolutePath,
                            type = getType(dest.name),
                            ownerId = when(val sender = message.senderId) {
                                is TdApi.MessageSenderUser -> sender.userId
                                else -> 0
                            },
                            timestamp = message.date * 1000L,
                            syncState = SyncState.SYNCED,
                            messageId = message.id
                        )

                        val current = _files.value.toMutableList()
                        // Avoid duplicates
                        if(current.none { it.name == sharedFile.name }) {
                            current.add(sharedFile)
                            _files.value = current
                        }
                        _syncState.value = SyncState.SYNCED
                    }
                }
            }
        }
    }

    fun uploadToShared(file: File, onProgress: (Int)->Unit = {}, onComplete: ()->Unit = {}, onError: (String)->Unit = {}) {
        if(currentChatId == 0L) {
            onError("Not connected to private chat")
            return
        }

        _syncState.value = SyncState.SYNCING

        val tempFile = SharedVaultFile(
            id = file.name,
            name = file.name,
            size = file.length(),
            path = file.absolutePath,
            type = getType(file.name),
            ownerId = myId,
            timestamp = System.currentTimeMillis(),
            syncState = SyncState.SYNCING
        )

        _files.value = _files.value + tempFile

        // Copy to local shared dir first
        val sharedDir = File(context.filesDir, "vault_shared").apply { mkdirs() }
        val dest = File(sharedDir, file.name)
        file.copyTo(dest, overwrite = true)

        // Send via TDLib to partner with special caption for sync
        val caption = "[SHARED_VAULT] ${file.name}"
        tdLib.sendFile(currentChatId, file.absolutePath, caption) { message ->
            // Update sync state to SYNCED
            _files.value = _files.value.map { f ->
                if(f.id == file.name) f.copy(syncState = SyncState.SYNCED, messageId = message.id, path = dest.absolutePath)
                else f
            }
            _syncState.value = SyncState.SYNCED
            onComplete()
        }
    }

    fun deleteFromShared(fileId: String, onComplete: ()->Unit = {}) {
        val file = _files.value.find { it.id == fileId }
        file?.let {
            // Delete local
            File(it.path).delete()

            // If this file was sent as message, delete message for both
            if(it.messageId != 0L && currentChatId != 0L) {
                tdLib.deleteMessage(currentChatId, it.messageId, true) {
                    _files.value = _files.value.filter { f -> f.id != fileId }
                    onComplete()
                }
            } else {
                _files.value = _files.value.filter { f -> f.id != fileId }
                onComplete()
            }
        }
    }

    fun renameInShared(fileId: String, newName: String, onComplete: ()->Unit = {}) {
        val file = _files.value.find { it.id == fileId }
        file?.let {
            val oldFile = File(it.path)
            val newFile = File(oldFile.parent, newName)
            if(oldFile.renameTo(newFile)) {
                _files.value = _files.value.map { f ->
                    if(f.id == fileId) f.copy(id = newName, name = newName, path = newFile.absolutePath)
                    else f
                }
                // Send rename notification via message edit? For simplicity, re-upload with new name
                // In real app, would need conflict handling
                onComplete()
            }
        }
    }

    fun syncNow() {
        _syncState.value = SyncState.SYNCING
        loadLocalFiles()
        // In real app, would fetch shared vault messages from chat history
        if(currentChatId != 0L) {
            tdLib.getChatHistory(currentChatId, limit = 100) { result ->
                result.messages.forEach { msg ->
                    handlePotentialSharedVaultMessage(msg)
                }
                _syncState.value = SyncState.SYNCED
            }
        }
    }

    private fun getType(name: String): VaultManager.VaultType {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when(ext) {
            "jpg","jpeg","png","webp" -> VaultManager.VaultType.IMAGE
            "mp4","mov","avi","mkv" -> VaultManager.VaultType.VIDEO
            "pdf","doc","docx","xls","xlsx","txt" -> VaultManager.VaultType.DOCUMENT
            else -> VaultManager.VaultType.OTHER
        }
    }
}
